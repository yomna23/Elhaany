import 'package:flutter/material.dart';
import 'package:elha2ny/Screens/HomePage/Components/body.dart';

class HomePage extends StatelessWidget {




  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Homepage(),

    );
  }
}

