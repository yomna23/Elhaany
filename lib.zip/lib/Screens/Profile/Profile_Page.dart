import 'package:elha2ny/Screens/Welcome/welcome_screen.dart';
import 'package:flutter/material.dart';
import 'package:elha2ny/Screens/Profile/Components/body.dart';



class UserProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return profilepage();
  }
}

