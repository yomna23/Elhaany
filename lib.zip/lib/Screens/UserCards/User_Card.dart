import 'package:elha2ny/Screens/UserCards/Components/Body.dart';
import 'package:flutter/material.dart';
import 'package:elha2ny/Screens/Signup/components/body.dart';

class UserCards extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: userCard(

      ),
    );
  }
}