import 'package:elha2ny/Network/Local/Cache.dart';
import 'package:flutter/material.dart';

import 'Screens/Welcome/welcome_screen.dart';

const kPrimaryColor = Color(0xFFFF314C);
const kPrimaryLightColor = Color(0xB0F8D8D8);
dynamic uId  ;


